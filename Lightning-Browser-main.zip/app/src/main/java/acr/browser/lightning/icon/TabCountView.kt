package acr.browser.lightning.icon

import acr.browser.lightning.R
import acr.browser.lightning.extensions.preferredLocale
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.CornerPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.View
import androidx.core.content.withStyledAttributes
import java.text.NumberFormat

/**
 * A view that draws a count enclosed by a border. Defaults to drawing zero, draws infinity if the
 * number is greater than 99.
 *
 * Attributes:
 * - [R.styleable.TabCountView_tabIconColor] - The color used to draw the number and border.
 * Defaults to black.
 * - [R.styleable.TabCountView_tabIconTextSize] - The count text size, defaults to 14.
 * - [R.styleable.TabCountView_tabIconBorderRadius] - The radius of the border's corners. Defaults
 * to 0.
 * - [R.styleable.TabCountView_tabIconBorderWidth] - The width of the border. Defaults to 0.
 */
class TabCountView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val numberFormat = NumberFormat.getInstance(context.preferredLocale)
    private val paint: Paint = Paint().apply {
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
    }
    private var borderRadius: Float = 0F
    private var borderWidth: Float = 0F
    private val workingRect = RectF()
    private val cornerPathEffect: CornerPathEffect

    private var count: Int = 0

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        context.withStyledAttributes(attrs, R.styleable.TabCountView) {
            paint.color = getColor(R.styleable.TabCountView_tabIconColor, Color.BLACK)
            paint.textSize = getDimension(R.styleable.TabCountView_tabIconTextSize, 14F)
            borderRadius = getDimension(R.styleable.TabCountView_tabIconBorderRadius, 0F)
            borderWidth = getDimension(R.styleable.TabCountView_tabIconBorderWidth, 0F)
        }
        cornerPathEffect = CornerPathEffect(borderRadius)
    }

    /**
     * Update the number count displayed by the view.
     */
    fun updateCount(count: Int) {
        this.count = count
        contentDescription = count.toString()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val text: String = if (count > MAX_DISPLAYABLE_NUMBER) {
            context.getString(R.string.infinity)
        } else {
            numberFormat.format(count)
        }

        workingRect.set(
            0f + borderWidth / 2,
            0f + borderWidth / 2,
            width.toFloat() - borderWidth / 2,
            height.toFloat() - borderWidth / 2
        )

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = borderWidth
        canvas.drawRoundRect(workingRect, borderRadius, borderRadius, paint)

        paint.style = Paint.Style.FILL

        val xPos = width / 2F
        val yPos = height / 2 - (paint.descent() + paint.ascent()) / 2

        canvas.drawText(text, xPos, yPos, paint)

        super.onDraw(canvas)
    }

    companion object {
        private const val MAX_DISPLAYABLE_NUMBER = 99
    }

}
